# BookNest - Online Book Store

React project for Assignment 8.2.2 (Scenario 2: Online Book Store).

## Features
- React Router navigation without page reload
- Home, Books, Book Details, Cart and About pages
- Dynamic `/books/:id` route using `useParams()`
- `useState()` for cart state
- `useEffect()` for loading and cleanup in Book Details
- Loading message: "Loading book details..."
- Book IDs 101, 102 and 103
- Invalid ID displays "Book Not Found"
- Go Back and Add to Cart buttons
- Cart count in navigation
- 404 Not Found page
- Responsive CSS

## Run in VS Code

```bash
npm install
npm run dev
```

Open the URL shown by Vite, usually:
`http://localhost:5173`

## Build
```bash
npm run build
```

## GitHub
```bash
git init
git add .
git commit -m "Create React online book store"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/book-store.git
git push -u origin main
```
