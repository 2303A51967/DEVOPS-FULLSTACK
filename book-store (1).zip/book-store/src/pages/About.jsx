export default function About() {
  return (
    <section className="content-page">
      <p className="eyebrow">ABOUT</p>
      <h1>About BookNest</h1>
      <p>
        BookNest is a simple Online Book Store built with React for demonstrating
        client-side routing and React lifecycle functionality.
      </p>
      <div className="feature-grid">
        <div><h3>⚡ Fast Navigation</h3><p>React Router changes pages without a full browser reload.</p></div>
        <div><h3>🔎 Dynamic Details</h3><p>Book IDs are read using useParams().</p></div>
        <div><h3>🛒 Cart State</h3><p>useState() keeps selected books in the navigation and cart.</p></div>
        <div><h3>♻️ Cleanup</h3><p>useEffect() cleans up the simulated data-loading timer.</p></div>
      </div>
    </section>
  );
}