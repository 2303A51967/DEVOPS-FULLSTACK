import { Link } from "react-router-dom";
import { books } from "../data/books";

export default function Books() {
  return (
    <section>
      <div className="page-heading">
        <div>
          <p className="eyebrow">COLLECTION</p>
          <h1>All Books</h1>
        </div>
        <p>{books.length} books available</p>
      </div>

      <div className="book-grid">
        {books.map((book) => (
          <article className="book-card" key={book.id}>
            <div className="cover">{book.emoji}</div>
            <div className="book-info">
              <span className="tag">{book.category}</span>
              <h2>{book.title}</h2>
              <p>by {book.author}</p>
              <div className="card-bottom">
                <strong>₹{book.price}</strong>
                <Link to={`/books/${book.id}`}>View Details</Link>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}