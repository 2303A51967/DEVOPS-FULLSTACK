function SubjectList({ subjects }) {
  return (
    <article className="card">
      <div className="card-title">
        <span className="icon">📚</span>
        <div>
          <h2>Subjects</h2>
          <p>Current semester subjects</p>
        </div>
      </div>

      <div className="subject-list">
        {subjects.map((subject) => (
          <div className="subject-item" key={subject.id}>
            <span>{subject.name}</span>
            <span className="subject-code">{subject.code}</span>
          </div>
        ))}
      </div>
    </article>
  );
}

export default SubjectList;