# Student Marks and Grade Management System

A complete React + Vite project for the Week 6.2 lab experiment: **Student Marks and Grade Management System**.

## Requirements covered

- React project created with Vite
- `StudentList` component
- `Student` component
- `MarksForm` component
- `Result` component
- `Grade` component
- Props for student ID, name, department, subjects, and marks
- `useState()` for student details and dynamic marks
- Total and average calculation
- Conditional grade calculation
- Pass/fail status
- Marks validation from 0 to 100
- Search students by name
- Class average
- Reusable components
- Responsive UI

## Grade rules

| Average | Grade |
|---|---|
| 90 - 100 | A+ |
| 80 - 89.99 | A |
| 70 - 79.99 | B |
| 60 - 69.99 | C |
| 50 - 59.99 | D |
| Below 50 | F |

A student passes only when every subject mark is at least 40 and all marks are entered.

## Run the project

Make sure Node.js is installed.

```bash
npm install
npm run dev
```

Open the URL printed by Vite, normally:

```text
http://localhost:5173
```

## Build for production

```bash
npm run build
npm run preview
```

## Project structure

```text
student-marks-management-system/
├── index.html
├── package.json
├── vite.config.js
├── README.md
└── src/
    ├── App.jsx
    ├── main.jsx
    ├── styles.css
    └── components/
        ├── StudentList.jsx
        ├── Student.jsx
        ├── MarksForm.jsx
        ├── Result.jsx
        └── Grade.jsx
```
