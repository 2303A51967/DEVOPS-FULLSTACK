function Grade({ average }) {
  let grade = "F";

  if (average >= 90) grade = "A+";
  else if (average >= 80) grade = "A";
  else if (average >= 70) grade = "B";
  else if (average >= 60) grade = "C";
  else if (average >= 50) grade = "D";

  return <span className={`grade grade-${grade.replace("+", "plus")}`}>{grade}</span>;
}

export default Grade;