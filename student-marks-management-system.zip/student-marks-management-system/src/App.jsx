import { useMemo, useState } from "react";
import StudentList from "./components/StudentList";
import Student from "./components/Student";
import MarksForm from "./components/MarksForm";
import Result from "./components/Result";

const initialStudents = [
  {
    id: "CS101",
    name: "Pradeep",
    department: "Computer Science",
    subjects: ["Java", "DBMS", "React", "Python", "DevOps"],
    marks: [82, 76, 91, 88, 79]
  },
  {
    id: "CS102",
    name: "Rahul",
    department: "Computer Science",
    subjects: ["Java", "DBMS", "React", "Python", "DevOps"],
    marks: [72, 81, 68, 75, 84]
  },
  {
    id: "CS103",
    name: "Sneha",
    department: "Computer Science",
    subjects: ["Java", "DBMS", "React", "Python", "DevOps"],
    marks: [95, 89, 92, 96, 90]
  },
  {
    id: "CS104",
    name: "Anjali",
    department: "Information Technology",
    subjects: ["Java", "DBMS", "React", "Python", "DevOps"],
    marks: [61, 70, 58, 66, 73]
  }
];

function App() {
  const [students, setStudents] = useState(initialStudents);
  const [selectedId, setSelectedId] = useState(initialStudents[0].id);
  const [search, setSearch] = useState("");

  const selectedStudent =
    students.find((student) => student.id === selectedId) ?? students[0];

  const filteredStudents = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return students;
    return students.filter((student) =>
      student.name.toLowerCase().includes(term)
    );
  }, [students, search]);

  const classAverage = useMemo(() => {
    if (!students.length) return 0;
    const averages = students.map((student) => {
      const total = student.marks.reduce((sum, mark) => sum + mark, 0);
      return total / student.marks.length;
    });
    return averages.reduce((sum, average) => sum + average, 0) / averages.length;
  }, [students]);

  function handleMarksChange(studentId, newMarks) {
    setStudents((currentStudents) =>
      currentStudents.map((student) =>
        student.id === studentId ? { ...student, marks: newMarks } : student
      )
    );
  }

  return (
    <div className="app">
      <header className="header">
        <div>
          <p className="eyebrow">React + Vite</p>
          <h1>Student Marks Management System</h1>
          <p className="subtitle">
            Enter marks, calculate results, and manage grades using Props and React State.
          </p>
        </div>
        <div className="class-average">
          <span>Class Average</span>
          <strong>{classAverage.toFixed(2)}%</strong>
        </div>
      </header>

      <main className="layout">
        <aside className="sidebar">
          <div className="panel-heading">
            <div>
              <h2>Students</h2>
              <span>{students.length} students</span>
            </div>
          </div>

          <input
            className="search"
            type="search"
            placeholder="Search by name..."
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />

          <StudentList
            students={filteredStudents}
            selectedId={selectedId}
            onSelect={setSelectedId}
          />

          {filteredStudents.length === 0 && (
            <p className="empty">No student found.</p>
          )}
        </aside>

        <section className="content">
          {selectedStudent ? (
            <>
              <Student student={selectedStudent} />

              <div className="grid">
                <MarksForm
                  student={selectedStudent}
                  onMarksChange={handleMarksChange}
                />
                <Result student={selectedStudent} />
              </div>
            </>
          ) : (
            <div className="empty-card">Select a student to continue.</div>
          )}
        </section>
      </main>

      <footer>
        <span>Student Marks & Grade Management System</span>
        <span>Props • useState • Conditional Rendering</span>
      </footer>
    </div>
  );
}

export default App;