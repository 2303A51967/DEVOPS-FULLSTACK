function Header() {
  return (
    <header className="header">
      <div className="header-inner">
        <div className="college-logo" aria-hidden="true">
          SU
        </div>
        <div>
          <h2>SR University</h2>
          <p>College Student Management System</p>
        </div>
      </div>
      <span className="header-badge">Student Portal</span>
    </header>
  );
}

export default Header;