function Student({ student }) {
  return (
    <section className="student-card">
      <div className="large-avatar">{student.name.charAt(0).toUpperCase()}</div>
      <div className="student-details">
        <p className="label">SELECTED STUDENT</p>
        <h2>{student.name}</h2>
        <div className="student-meta">
          <span><b>ID:</b> {student.id}</span>
          <span><b>Department:</b> {student.department}</span>
          <span><b>Subjects:</b> {student.subjects.length}</span>
        </div>
      </div>
    </section>
  );
}

export default Student;