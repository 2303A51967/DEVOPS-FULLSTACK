import { useState } from "react";
import { NavLink, Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import Books from "./pages/Books";
import BookDetails from "./pages/BookDetails";
import Cart from "./pages/Cart";
import About from "./pages/About";
import NotFound from "./pages/NotFound";

export default function App() {
  const [cart, setCart] = useState([]);

  function addToCart(book) {
    setCart((current) => {
      const exists = current.some((item) => item.id === book.id);
      return exists ? current : [...current, book];
    });
  }

  function removeFromCart(id) {
    setCart((current) => current.filter((item) => item.id !== id));
  }

  return (
    <div className="app">
      <header className="navbar">
        <NavLink to="/" className="brand">📚 BookNest</NavLink>
        <nav>
          <NavLink to="/" end>Home</NavLink>
          <NavLink to="/books">Books</NavLink>
          <NavLink to="/cart">Cart <span className="cart-badge">{cart.length}</span></NavLink>
          <NavLink to="/about">About</NavLink>
        </nav>
      </header>

      <main className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/books" element={<Books />} />
          <Route path="/books/:id" element={<BookDetails onAddToCart={addToCart} />} />
          <Route path="/cart" element={<Cart cart={cart} onRemove={removeFromCart} />} />
          <Route path="/about" element={<About />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>

      <footer>© 2026 BookNest • React Routing Assignment</footer>
    </div>
  );
}