import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="status-box">
      <div className="error-number">404</div>
      <h1>Page Not Found</h1>
      <p>The page you requested does not exist.</p>
      <Link className="button" to="/">Go Home</Link>
    </div>
  );
}