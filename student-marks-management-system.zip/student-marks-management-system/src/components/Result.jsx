import Grade from "./Grade";

function Result({ student }) {
  const validMarks = student.marks.filter(
    (mark) => mark !== "" && Number.isFinite(Number(mark))
  );
  const total = validMarks.reduce((sum, mark) => sum + Number(mark), 0);
  const average = student.marks.length
    ? total / student.marks.length
    : 0;

  const pass = student.marks.length === validMarks.length &&
    student.marks.every((mark) => Number(mark) >= 40);

  return (
    <section className="card result-card">
      <div className="card-title">
        <div>
          <p className="label">CALCULATED RESULT</p>
          <h3>Performance</h3>
        </div>
        <Grade average={average} />
      </div>

      <div className="score-box">
        <span>Average</span>
        <strong>{average.toFixed(2)}%</strong>
      </div>

      <div className="stats">
        <div>
          <span>Total Marks</span>
          <strong>{total} / {student.subjects.length * 100}</strong>
        </div>
        <div>
          <span>Grade</span>
          <strong><Grade average={average} /></strong>
        </div>
        <div>
          <span>Status</span>
          <strong className={pass ? "pass" : "fail"}>
            {pass ? "PASS" : "FAIL"}
          </strong>
        </div>
      </div>

      <div className="subject-results">
        {student.subjects.map((subject, index) => {
          const mark = Number(student.marks[index]);
          const isPass = Number.isFinite(mark) && mark >= 40;
          return (
            <div className="subject-result" key={subject}>
              <span>{subject}</span>
              <div className="bar">
                <span style={{ width: `${Number.isFinite(mark) ? mark : 0}%` }} />
              </div>
              <strong>{Number.isFinite(mark) ? mark : 0}</strong>
              <small className={isPass ? "pass" : "fail"}>
                {isPass ? "Pass" : "Fail"}
              </small>
            </div>
          );
        })}
      </div>
    </section>
  );
}

export default Result;