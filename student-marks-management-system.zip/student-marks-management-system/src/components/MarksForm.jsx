import { useEffect, useState } from "react";

function MarksForm({ student, onMarksChange }) {
  const [marks, setMarks] = useState(student.marks);

  useEffect(() => {
    setMarks(student.marks);
  }, [student]);

  function updateMark(index, value) {
    const nextMarks = [...marks];
    nextMarks[index] = value;
    setMarks(nextMarks);
    onMarksChange(student.id, nextMarks);
  }

  return (
    <section className="card">
      <div className="card-title">
        <div>
          <p className="label">MARKS ENTRY</p>
          <h3>Subject Marks</h3>
        </div>
        <span className="hint">0 - 100</span>
      </div>

      <div className="marks-form">
        {student.subjects.map((subject, index) => (
          <label className="mark-row" key={subject}>
            <span>{subject}</span>
            <div className="input-wrap">
              <input
                type="number"
                min="0"
                max="100"
                value={marks[index] ?? ""}
                onChange={(event) => {
                  const raw = event.target.value;
                  if (raw === "") {
                    updateMark(index, "");
                    return;
                  }
                  const number = Number(raw);
                  if (number >= 0 && number <= 100) {
                    updateMark(index, number);
                  }
                }}
              />
              <span>/ 100</span>
            </div>
          </label>
        ))}
      </div>

      <p className="form-note">
        Marks are validated between 0 and 100 and update the result automatically.
      </p>
    </section>
  );
}

export default MarksForm;