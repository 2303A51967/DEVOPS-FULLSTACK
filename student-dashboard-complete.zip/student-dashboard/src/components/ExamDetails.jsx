function ExamDetails({ exam }) {
  return (
    <article className="card">
      <div className="card-title">
        <span className="icon">📝</span>
        <div>
          <h2>Examination Details</h2>
          <p>Upcoming examination information</p>
        </div>
      </div>

      <div className="exam-details">
        <div className="detail">
          <span className="label">Examination</span>
          <strong>{exam.name}</strong>
        </div>
        <div className="detail">
          <span className="label">Date</span>
          <strong>{exam.date}</strong>
        </div>
        <div className="detail">
          <span className="label">Time</span>
          <strong>{exam.time}</strong>
        </div>
        <div className="detail">
          <span className="label">Venue</span>
          <strong>{exam.venue}</strong>
        </div>
      </div>
    </article>
  );
}

export default ExamDetails;