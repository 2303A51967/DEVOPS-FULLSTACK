import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { books } from "../data/books";

export default function BookDetails({ onAddToCart }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    setBook(null);

    const timer = setTimeout(() => {
      const selectedBook = books.find((item) => item.id === Number(id));
      setBook(selectedBook || null);
      setLoading(false);
    }, 500);

    // Cleanup runs when the ID changes or the component unmounts.
    return () => {
      clearTimeout(timer);
      console.log(`Cleaned up BookDetails for book ID: ${id}`);
    };
  }, [id]);

  if (loading) {
    return <div className="status-box">Loading book details...</div>;
  }

  if (!book) {
    return (
      <div className="status-box">
        <h1>Book Not Found</h1>
        <p>The book ID <strong>{id}</strong> does not exist.</p>
        <Link className="button" to="/books">Back to Books</Link>
      </div>
    );
  }

  return (
    <section className="details">
      <button className="back-button" onClick={() => navigate(-1)}>← Go Back</button>

      <div className="details-card">
        <div className="details-cover">{book.emoji}</div>
        <div>
          <span className="tag">{book.category}</span>
          <h1>{book.title}</h1>
          <p className="author">Written by {book.author}</p>
          <p className="description">{book.description}</p>
          <div className="price">₹{book.price}</div>
          <button className="button" onClick={() => onAddToCart(book)}>
            Add to Cart
          </button>
        </div>
      </div>

      <div className="route-note">
        Current route: <code>/books/{id}</code> • useParams() supplied the book ID.
      </div>
    </section>
  );
}