function StudentList({ students, selectedId, onSelect }) {
  return (
    <div className="student-list">
      {students.map((student) => (
        <button
          key={student.id}
          className={`student-item ${selectedId === student.id ? "selected" : ""}`}
          onClick={() => onSelect(student.id)}
          type="button"
        >
          <span className="avatar">{student.name.charAt(0).toUpperCase()}</span>
          <span className="student-list-info">
            <strong>{student.name}</strong>
            <small>{student.id} • {student.department}</small>
          </span>
          <span className="arrow">›</span>
        </button>
      ))}
    </div>
  );
}

export default StudentList;