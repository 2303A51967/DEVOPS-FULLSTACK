import { Link } from "react-router-dom";

export default function Cart({ cart, onRemove }) {
  const total = cart.reduce((sum, book) => sum + book.price, 0);

  return (
    <section>
      <div className="page-heading">
        <div>
          <p className="eyebrow">YOUR SELECTION</p>
          <h1>Shopping Cart</h1>
        </div>
      </div>

      {cart.length === 0 ? (
        <div className="status-box">
          <h2>Your cart is empty</h2>
          <p>Add a book from the Books page to see it here.</p>
          <Link className="button" to="/books">Browse Books</Link>
        </div>
      ) : (
        <div className="cart-layout">
          <div className="cart-list">
            {cart.map((book) => (
              <div className="cart-item" key={book.id}>
                <div className="mini-cover">{book.emoji}</div>
                <div>
                  <h3>{book.title}</h3>
                  <p>{book.author}</p>
                </div>
                <strong>₹{book.price}</strong>
                <button onClick={() => onRemove(book.id)}>Remove</button>
              </div>
            ))}
          </div>
          <aside className="summary">
            <h2>Order Summary</h2>
            <p>Items <span>{cart.length}</span></p>
            <p className="total">Total <span>₹{total}</span></p>
            <button className="button full" onClick={() => alert("Demo checkout completed!")}>
              Checkout
            </button>
          </aside>
        </div>
      )}
    </section>
  );
}