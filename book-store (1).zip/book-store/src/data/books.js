export const books = [
  {
    id: 101,
    title: "The Silent Forest",
    author: "Arjun Mehta",
    price: 399,
    category: "Adventure",
    emoji: "🌲",
    description: "A young explorer discovers an old mystery hidden deep inside a silent forest."
  },
  {
    id: 102,
    title: "Learning Java",
    author: "Priya Sharma",
    price: 549,
    category: "Programming",
    emoji: "☕",
    description: "A beginner-friendly guide to Java fundamentals, OOP, collections and problem solving."
  },
  {
    id: 103,
    title: "The Future of AI",
    author: "Rahul Verma",
    price: 699,
    category: "Technology",
    emoji: "🤖",
    description: "An introduction to artificial intelligence, machine learning and the technologies shaping tomorrow."
  }
];