import { Link } from "react-router-dom";

export default function Home() {
  return (
    <section className="hero">
      <div>
        <p className="eyebrow">ONLINE BOOK STORE</p>
        <h1>Find your next<br /><span>great read.</span></h1>
        <p className="hero-text">
          Explore books, discover new ideas and build your personal collection.
          Navigate through the store without reloading the page.
        </p>
        <Link className="button" to="/books">Explore Books →</Link>
      </div>
      <div className="hero-card">
        <div className="book-stack">📚</div>
        <h2>Read. Learn. Grow.</h2>
        <p>Three featured books are waiting for you.</p>
      </div>
    </section>
  );
}